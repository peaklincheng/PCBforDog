extern void timeLine(void);
extern char runLine_state;
