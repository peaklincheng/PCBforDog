#ifndef WATCHDOG_H_INCLUDED
#define WATCHDOG_H_INCLUDED
extern void watch_dog_init(void);
extern void watch_feed_dog(void);


#endif // WATCHDOG_H_INCLUDED
