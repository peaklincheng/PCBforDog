extern void water_op(void);
extern void water_cl(void);
extern void water_set(void);

