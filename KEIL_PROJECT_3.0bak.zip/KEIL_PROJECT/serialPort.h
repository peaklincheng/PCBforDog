extern void send_string(char* s);
